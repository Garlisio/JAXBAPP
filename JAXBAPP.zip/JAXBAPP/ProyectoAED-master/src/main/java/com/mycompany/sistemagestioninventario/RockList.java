package com.mycompany.sistemagestioninventario;

import jakarta.xml.bind.annotation.XmlElement;
import jakarta.xml.bind.annotation.XmlRootElement;
import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

/**
 *
 * @author Sergio
 */
@XmlRootElement(name = "products")
public class RockList implements Serializable{

    private List<Rock> rocks;

    public RockList() {
        this.rocks = new ArrayList<>();
    }
    
    public void addList(List<Rock> x){
        rocks = x;
    }

    @XmlElement(name = "product")
    public List<Rock> getRocks() {
        return rocks;
    }

    public void addRock(Rock product) {
        this.rocks.add(product);
    }

    public Rock getRockAt(int index) {
        if (index >= 0 && index < rocks.size()) {
            return rocks.get(index);
        } else {
            new ErrorHandler("Índice fuera de rango.", null);
            return null;
        }
    }

    public void updateRockAt(int index, Rock updatedRock) {
        if (index >= 0 && index < rocks.size()) {
            rocks.set(index, updatedRock);
        } else {
            new ErrorHandler("Índice fuera de rango.", null);
        }
    }
}
